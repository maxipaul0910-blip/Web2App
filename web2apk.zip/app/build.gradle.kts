plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Values passed in by the GitHub workflow (-PappName=... -PappUrl=... -PappId=...)
val appName = (findProperty("appName") as String?)?.takeIf { it.isNotBlank() } ?: "Web App"
val appUrl = (findProperty("appUrl") as String?)?.trim() ?: ""
val appId = (findProperty("appId") as String?)?.takeIf { it.isNotBlank() } ?: "com.example.webapp"

android {
    namespace = "com.web2apk.app"
    compileSdk = 34

    defaultConfig {
        applicationId = appId
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        val safeUrl = appUrl.replace("\\", "\\\\").replace("\"", "\\\"")
        buildConfigField("String", "START_URL", "\"$safeUrl\"")
        resValue("string", "app_name", appName.replace("'", "\\'").replace("\"", ""))
    }

    buildFeatures {
        buildConfig = true
    }

    // Everything in /www is bundled into the app (used when no URL is given)
    sourceSets {
        getByName("main") {
            assets.srcDirs("../www")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
